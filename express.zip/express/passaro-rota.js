var express = require('express')
var router = express.Router()
// middleware específico para essa rota
router.use(function timeLog(req, res, next) {
    // timestamp em milisegundos
    let date_ob = new Date(Date.now());
    let dia = date_ob.getDate();
    let mes = date_ob.getMonth() + 1;
    let ano = date_ob.getFullYear();
    let hora = date_ob.getHours();
    let minutos = date_ob.getMinutes();
    let segundos = date_ob.getSeconds();

    console.log(hora + ':' + minutos + ':' + segundos, dia + "/" + mes + "/" + ano)
    next()
})

router.get('/', function (req, res) {
    res.send('Pássaros - Página Principal')
})
router.get('/about', function (req, res) {
    res.send('Sobre os Pássaros')
})
module.exports = router