const express = require('express');
const app = express();
var mysql = require('mysql');
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "node"
});
con.connect(function (err) {
    if (err) throw err;
    console.log("Conectado!");
});
app.use(express.urlencoded({ extended: true }))
app.set('view engine', 'ejs')
app.get('/', function (req, res) {
    res.render('teste.ejs');
});
app.get('/usuarios', function (req, res) {
    var sql = "SELECT * FROM usuario"
    con.query(sql, function (err, result, fields) {
        if (err) throw err;
        res.render('listar', { dadosUsuario: result });
    });
});
app.listen(3000, function () {
    console.log("Servidor Escutando na porta 80");
})